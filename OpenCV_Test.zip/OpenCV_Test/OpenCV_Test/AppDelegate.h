//
//  AppDelegate.h
//  OpenCV_Test
//
//  Created by TuLigen on 17/4/11.
//  Copyright © 2017年 TuLigen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

