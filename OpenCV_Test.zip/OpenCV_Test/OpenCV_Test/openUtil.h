//
//  openUtil.h
//  OpenCV_Test
//
//  Created by TuLigen on 17/4/11.
//  Copyright © 2017年 TuLigen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface openUtil : NSObject
//+(cv::Mat)cvMatFromUIImage:(UIImage *)image;

//+(UIImage *)UIImageFromCVMat:(cv::Mat)cvMat;
@end
